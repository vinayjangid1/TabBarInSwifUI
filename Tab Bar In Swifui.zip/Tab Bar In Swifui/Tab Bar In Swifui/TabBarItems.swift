//
//  ContentView.swift
//  Tab Bar In Swifui
//
//  Created by Vinay Arthonsys on 27/05/24.
//

import SwiftUI

struct TabBarItems: View {
    @State var selectedTabBar: TabBars = .Home
    
    enum TabBars{
        case Home
        case Products
        case Notifications
        case settings
        case profile
    }
    var body: some View {
        TabView(selection: $selectedTabBar,
                content:  {
            Text("Home").tabItem {
                Image(systemName: "house")
                Text("House")
            }.tag(1)
            Text("Products").tabItem {
                Image(systemName: "shippingbox.fill")
                Text("Products")
            }.tag(2)
            Text("Notifications").tabItem {
                Image(systemName: "bell.fill")
                Text("Notifications")
            }.tag(2)
            Text("Settings").tabItem {
                Image(systemName: "gear")
                Text("Settings")
            }.tag(2)
            Text("Profile").tabItem {
                Image(systemName: "person.crop.circle")
                Text("Profile")
            }.tag(2)
        })
    }
}

#Preview {
    TabBarItems()
}

//
//  Tab_Bar_In_SwifuiApp.swift
//  Tab Bar In Swifui
//
//  Created by Vinay Arthonsys on 27/05/24.
//

import SwiftUI

@main
struct Tab_Bar_In_SwifuiApp: App {
    var body: some Scene {
        WindowGroup {
            TabBarItems()
        }
    }
}
